<html>
    <title></title>
    <head>

    </head>

    <style>
        body{
            background-image: url('https://www.teahub.io/photos/full/247-2477158_windows-10-background-green.jpg');
        }
    </style>
    <body>

    </body>
</html>