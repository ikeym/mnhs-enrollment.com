<?php
include_once 'database.php';
$result = mysqli_query($conn,"SELECT * FROM table_attendance");
?>

<?php
if(isset($_SERVER['HTTPS'])&& $_SERVER['HTTPS']=='on'){
$url="https://";
}else{
    $url="https://";
    $url.=$_SERVER['HTTP_HOST'];
    $url.=$_SERVER['REQUEST_URI'];
    $url;
}
$page=$url;
$sec="5";

?>

<!DOCTYPE html>
<html>
<head>
<title>Enrolee Via Qr Code</title>
    <meta http-equiv="refresh" content="<?php echo $sec;?>" URL"<?php echo $page;?>




    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

</head>

<style>
    body{
        background-image: url('https://th.bing.com/th/id/R.60bcaf1bb1186807b999aa92e9bc8268?rik=N6mHjGGC5QEtwA&riu=http%3a%2f%2fwww.yeaheducation.com.au%2fwp-content%2fuploads%2f2016%2f08%2fSlider-Home-yeaheducation-01-fondo.jpg&ehk=AG07npfAXK0VMZYwNF%2ftBkrdi3UFxSRJL46GqedwYLw%3d&risl=&pid=ImgRaw&r=0');
    }
</style>
<body>
<div> 
<p  style="margin-left:0.5%;margin-top:0.5%;">
        <a href="http://localhost:8090/Here/Research%20Enrollment%20System/Morong%20Senior%20HighSchool%20Enrollment%20System/admin/index.php" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-home"></span> Home
        </a>
      </p> 

      <p class="bg-info" style="padding-bottom:0.5%;margin-left: 0.5%;border-style:solid;border-color:white;border-radius:5px;margin-right:70%;">This page is for existing student of school only.</p>
</div>
<div style="margin-left:5.5%;margin-top:0.5%;">

<?php

if(mysqli_num_rows($result)>0){
?>

<table style="border-width: 1px;border-style:solid;">
<tr class="bg-info" >
<td style="border-width: 1px;border-style:solid;font-size :250%;"> <b>  ID  </b></td>
<td style="border-width: 1px;border-style:solid;font-size :250%;"><b> STUDENTID</b></td>
<td style="border-width: 1px;border-style:solid;font-size: 250%;"><b> ENROLLED</b></td>
<td style="border-width: 1px;border-style:solid;font-size :250%;"><b> ACTION</b></td>
</tr>
<?php
$i=0;
while($row=mysqli_fetch_array($result)){

?>
<tr>
<td style="border-width: 1px;border-style:solid;text-align:center;"><?php echo $row["ID"]; ?></td>
<td style="border-width: 1px;border-style:solid;text-align:center;"><?php echo $row["STUDENTID"]; ?></td>
<td style="border-width: 1px;border-style:solid;text-align:center;"><?php echo $row["TIMEIN"]; ?></td>

<td>  
     <p style="margin-left:20%;margin-top:2%; margin-bottom:4%;">
        <a  href="delete.php? id=<?php echo $row["ID"]; ?>" style="font-size: 80%;" class="btn btn-danger btn-lg">
          <span class="glyphicon glyphicon-trash"></span> Delete 
        </a></td>
</p>

</tr>
<?php
}
$i++;
}
?>
</table>
</div>
</body>
</html> 