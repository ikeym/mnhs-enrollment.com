﻿<?php
include_once 'database.php';
$id = $_GET['id'];  
      $query = "DELETE FROM `table_attendance` WHERE id = '$id'";  
      $run = mysqli_query($conn,$query);  

header("Location:retrieve.php");
?> 