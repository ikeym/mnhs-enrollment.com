﻿<?php
include_once 'database.php';
if(isset($_POST['btn-save']))
{
// variables for input data

$ID = $_POST['ID'];
$STUDENTID = $_POST['STUDENTID'];
$TIMEIN = $_POST['TIMEIN'];
// sql query for inserting data into database

mysqli_query($conn,"insert into table_attencance(ID,STUDENTID,TIMEIN) values ('$ID','$STUDENTID','$TIMEIN')") or die(mysqli_error());
echo "<p align=center>Data Added Successfully.</p>";
}
?> 