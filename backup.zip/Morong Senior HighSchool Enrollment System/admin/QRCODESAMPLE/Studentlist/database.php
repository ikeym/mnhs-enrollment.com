﻿<?php
$servername='localhost:3310';
$username='root';
$password='';
$dbname="qrcodedb";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn){
die('Could not Connect My Sql:'.mysql_error());
}
?> 

