<?php
$server = "localhost:3310";
$username="root";
$password="";
$dbname="qrcodedb";

$conn = new mysqli($server,$username,$password,$dbname);
if($conn->connect_error){
    die("Connection failed" .$conn->connect_error );
}

if(isset($_POST['text'])){

$voice = new com("SAPI.SpVoice");
$text=$_POST['text'];
$message = $text."Enrolled Successfuly";

$sql ="INSERT INTO table_attendance(STUDENTID,TIMEIN) VALUES ('$text',NOW())";
if($conn->query($sql)==TRUE){
    $voice->speak($message);
    ECHO "Successfully Inserted";
}else{
    echo "Error : " . $sql . "<br>" . $connect_error;
}
header("location: index.php");
}
$conn->close();
?>